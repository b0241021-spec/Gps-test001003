package com.gpssimulator.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.gpssimulator.R
import com.gpssimulator.data.GPSSimulatorStateManager
import com.gpssimulator.utils.GPSCalculator
import com.gpssimulator.utils.GPSCoordinate
import com.gpssimulator.utils.LogManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private var googleMap: GoogleMap? = null
    private lateinit var stateManager: GPSSimulatorStateManager
    private var lastSimulationTime = System.currentTimeMillis()

    private lateinit var directionSlider: SeekBar
    private lateinit var speedSlider: SeekBar
    private lateinit var scaleSlider: SeekBar
    private lateinit var simulationSwitch: Switch
    private lateinit var movingSwitch: Switch
    private lateinit var statusText: TextView
    private lateinit var locationText: TextView
    private lateinit var directionText: TextView
    private lateinit var speedText: TextView
    private lateinit var scaleText: TextView
    private lateinit var resetButton: Button
    private var arrowView: ArrowView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            LogManager.init(this)
            LogManager.writeLog("MainActivity onCreate started")

            setContentView(R.layout.activity_main)
            stateManager = GPSSimulatorStateManager()

            initializeUI()
            initializeMap()
            requestPermissions()
            observeState()
            startSimulationLoop()

            LogManager.writeLog("MainActivity onCreate completed successfully")
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "onCreate failed", e)
            showErrorDialog("初始化失敗", e.message ?: "未知錯誤")
        }
    }

    private fun initializeUI() {
        try {
            LogManager.writeLog("Initializing UI components")

            directionSlider = findViewById(R.id.directionSlider)
            speedSlider = findViewById(R.id.speedSlider)
            scaleSlider = findViewById(R.id.scaleSlider)
            simulationSwitch = findViewById(R.id.simulationSwitch)
            movingSwitch = findViewById(R.id.movingSwitch)
            statusText = findViewById(R.id.statusText)
            locationText = findViewById(R.id.locationText)
            directionText = findViewById(R.id.directionText)
            speedText = findViewById(R.id.speedText)
            scaleText = findViewById(R.id.scaleText)
            resetButton = findViewById(R.id.resetButton)
            arrowView = findViewById(R.id.arrowView)

            directionSlider.max = 359
            directionSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        stateManager.updateDirection(progress.toDouble())
                        arrowView?.setDirection(progress.toDouble())
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })

            speedSlider.max = 200
            speedSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val speed = progress / 10.0
                        stateManager.updateSpeed(speed)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })

            scaleSlider.max = 299
            scaleSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val scale = 1.0 + progress
                        stateManager.updateScale(scale)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })

            simulationSwitch.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    stateManager.startSimulation()
                } else {
                    stateManager.stopSimulation()
                    movingSwitch.isChecked = false
                }
            }

            movingSwitch.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked && stateManager.state.value.isSimulating) {
                    stateManager.startMoving()
                } else {
                    stateManager.stopMoving()
                }
            }

            resetButton.setOnClickListener {
                stateManager.reset()
                directionSlider.progress = 0
                speedSlider.progress = 0
                scaleSlider.progress = 0
                simulationSwitch.isChecked = false
                movingSwitch.isChecked = false
                arrowView?.setDirection(0.0)
                LogManager.writeLog("Reset button clicked")
            }

            LogManager.writeLog("UI components initialized successfully")
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "initializeUI failed", e)
            throw e
        }
    }

    private fun initializeMap() {
        try {
            LogManager.writeLog("Initializing Google Maps")
            val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as? SupportMapFragment
            if (mapFragment == null) {
                LogManager.writeError("MainActivity", "Map fragment not found")
                return
            }

            mapFragment.getMapAsync { map ->
                try {
                    googleMap = map
                    val initialLocation = LatLng(25.0330, 121.5654)
                    googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(initialLocation, 15f))
                    updateMapMarker()
                    LogManager.writeLog("Google Maps initialized successfully")
                } catch (e: Exception) {
                    LogManager.writeError("MainActivity", "Map initialization failed", e)
                }
            }
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "initializeMap failed", e)
        }
    }

    private fun observeState() {
        try {
            lifecycleScope.launch {
                stateManager.state.collect { state ->
                    try {
                        locationText.text = "位置: ${state.currentLocation.latitude.format(6)}, ${state.currentLocation.longitude.format(6)}"
                        directionText.text = "方向: ${state.direction.toInt()}°"
                        speedText.text = "速度: ${state.speed.format(1)} km/hr"
                        scaleText.text = "大小: ${state.scale.toInt()}%"
                        statusText.text = state.statusMessage

                        directionSlider.progress = state.direction.toInt()
                        speedSlider.progress = (state.speed * 10).toInt()
                        scaleSlider.progress = (state.scale - 1).toInt()

                        simulationSwitch.isChecked = state.isSimulating
                        movingSwitch.isChecked = state.isMoving && state.isSimulating

                        updateMapMarker()
                    } catch (e: Exception) {
                        LogManager.writeError("MainActivity", "observeState update failed", e)
                    }
                }
            }
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "observeState failed", e)
        }
    }

    private fun updateMapMarker() {
        try {
            if (googleMap == null) return

            googleMap?.clear()
            val state = stateManager.state.value
            val location = LatLng(state.currentLocation.latitude, state.currentLocation.longitude)

            googleMap?.addMarker(
                MarkerOptions()
                    .position(location)
                    .title("GPS 位置")
                    .snippet("${state.currentLocation.latitude.format(6)}, ${state.currentLocation.longitude.format(6)}")
            )

            if (state.isSimulating) {
                googleMap?.animateCamera(CameraUpdateFactory.newLatLng(location))
            }
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "updateMapMarker failed", e)
        }
    }

    private fun startSimulationLoop() {
        try {
            lifecycleScope.launch {
                while (true) {
                    try {
                        val state = stateManager.state.value
                        if (state.isSimulating && state.isMoving && state.speed > 0) {
                            val now = System.currentTimeMillis()
                            val elapsedSeconds = (now - lastSimulationTime) / 1000.0
                            lastSimulationTime = now

                            val newLocation = GPSCalculator.calculateNextLocation(
                                state.currentLocation,
                                state.direction,
                                state.speed,
                                elapsedSeconds.coerceAtMost(1.0)
                            )

                            stateManager.updateLocation(newLocation)
                        }
                        Thread.sleep(1000)
                    } catch (e: Exception) {
                        LogManager.writeError("MainActivity", "Simulation loop error", e)
                    }
                }
            }
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "startSimulationLoop failed", e)
        }
    }

    private fun requestPermissions() {
        try {
            val permissions = mutableListOf(
                Manifest.permission.INTERNET,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                permissions.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }

            val missingPermissions = permissions.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }

            if (missingPermissions.isNotEmpty()) {
                LogManager.writeLog("Requesting permissions: $missingPermissions")
                ActivityCompat.requestPermissions(
                    this,
                    missingPermissions.toTypedArray(),
                    PERMISSION_REQUEST_CODE
                )
            } else {
                LogManager.writeLog("All permissions already granted")
            }
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "requestPermissions failed", e)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        try {
            if (requestCode == PERMISSION_REQUEST_CODE) {
                val grantedPermissions = permissions.filterIndexed { index, _ ->
                    grantResults[index] == PackageManager.PERMISSION_GRANTED
                }
                LogManager.writeLog("Permissions granted: $grantedPermissions")
            }
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "onRequestPermissionsResult failed", e)
        }
    }

    private fun showErrorDialog(title: String, message: String) {
        try {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("確定") { _, _ -> }
                .show()
        } catch (e: Exception) {
            LogManager.writeError("MainActivity", "showErrorDialog failed", e)
        }
    }

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
    }
}

private fun Double.format(digits: Int): String = "%.${digits}f".format(this)
